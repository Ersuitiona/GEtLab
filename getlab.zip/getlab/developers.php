<?php include('header_dashboard.php'); ?>
    <body id="class_div">
		<?php include('navbar_about.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span12" id="content">
                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
								<div class="navbar navbar-inner block-header">
									<div id="" class="muted pull-right"><a href="index.php"><i class="icon-arrow-left"></i> Back</a></div>
								</div>
                            <div class="block-content collapse in">
							<h3>Developers</h3>
							<hr>
                                <div class="span3">
										<center>
										<img id="developers" src="admin/images/santhan.jpg" class="img-circle">
										<hr>
										<p>Name: Santhanu Gireesh</p>
										<p>Address: TVM</p>
										<p>Email: santhanugireesh6@gmail.com</p>
										
										</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/sanil.jpg" class="img-circle">
								<hr>
											<p>Name: Sanil Babu</p>

										<p>Address: Kozhikode</p>
										<p>Email: sanilbabusb@gmail.com</p>
										
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/athira1.jpg" class="img-circle">
								<hr>
												<p>Name: Athira</p>
										<p>Address: </p>TVM
										<p>Email: athiraka29@gmail.com</p>
										
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/ashikha.jpg" class="img-circle">
								<hr>
												<p>Name: Ashikha</p>
										<p>Address: Malapuram</p>
										<p>Email: oashikha@gmail.com</p>
										
								</center>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>
</html>