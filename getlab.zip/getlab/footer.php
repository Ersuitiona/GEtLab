<center>
		<footer>
		
		<p>GECI GET LAB Copyright 2024</p>
			<!-- <p>Programmed by: John Kevin Lorayna BSIS 4-A</p> -->
		</footer>
</center>

